<?php require_once 'config.inc.php'; ?>
<?php
    $query = mysql_query("SELECT * FROM `news` ORDER BY `date` DESC LIMIT 20");

    $news = array();
    while($row = mysql_fetch_array($query)) {
        $news[] = $row;
    }
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ru">
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
    <title></title>

    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            var inProcess = false;
            var num = 20;

            $(window).scroll(function() {
                if($(window).scrollTop() + $(window).height() >= $(document).height() && !inProcess) {

                    $.ajax({
                        url: 'load.php',
                        method: 'GET',
                        data: {"num" : num},
                        beforeSend: function() {
                            inProcess = true;
                        }
                    }).done(function(data){
                        data = jQuery.parseJSON(data);

                        if (data.length > 0) {
                            $.each(data, function(index, data){
                                $("#news").append("<p><strong>" + data.date + "</strong>. " + data.text + "</p>");
                            });

                            inProcess = false;
                            num += 10;
                        }
                    });

                }
            });
            function scroll_fn(){
                document_height = $(document).height();
                scroll_so_far = $(window).scrollTop();
                window_height = $(window).height();
                max_scroll = document_height-window_height;
                scroll_percentage = scroll_so_far/(max_scroll/100);
                $('#loading').width(scroll_percentage + '%');
            }
            $(window).scroll(function() {
                scroll_fn();
            });
            $(window).resize(function() {
                scroll_fn();
            });
        });
    </script>
<style type="text/css">
#loading {
  background-color: #EF4848;
  height: 3px;
  width: 0px;
  position: fixed;
  left: 0px;
  top: 0px;
}
</style>
</head>
<body>
<div id="loading"></div>
<div id="news">
<?php foreach ($news as $n): ?>
    <p><strong><?php echo $n['date'] ?></strong>. <?php echo $n['text'] ?></p>
<?php endforeach ?>
</div>

</body>
</html>
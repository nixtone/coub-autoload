<?php

require_once 'config.inc.php';

$num = $_GET['num'];

$query = mysql_query("SELECT * FROM `news` ORDER BY `date` DESC LIMIT {$num}, 10");

$news = array();
while ($row = mysql_fetch_array($query)) {
    $news[] = $row;
}

echo json_encode($news);